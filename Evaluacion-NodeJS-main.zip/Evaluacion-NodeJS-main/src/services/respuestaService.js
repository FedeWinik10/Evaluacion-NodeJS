import sql from 'mssql'
import config from '../models/db.js';
export class RespuestaService{

    
    createRespuesta = async (respuesta) => {
        const connection = await sql.connect(config);
        const result = await connection.request()
        .input("pIdUsuario", respuesta.IdUsuario)
        .input("pRespuestaSeleccionada", respuesta.RespuestaSeleccionada)
        .input("pRespuestaCorrecta", respuesta.RespuestaCorrecta)
        .input("pFechaDeCreacion", respuesta.FechaDeCreacion)
        .query(`INSERT INTO Respuestas(IdUsuario, RespuestaSeleccionada, RespuestaCorrecta, FechaDeCreacion) VALUES (@pIdUsuario, @pRespuestaSeleccionada, @pRespuestaCorrecta, @pFechaDeCreacion)`);

        return result.recordset;
    }

}