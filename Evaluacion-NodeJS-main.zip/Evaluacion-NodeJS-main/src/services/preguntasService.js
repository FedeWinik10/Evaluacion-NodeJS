import sql from 'mssql'
import config from '../models/db.js';
import 'dotenv/config'
export class PreguntaService{

    getPreguntasByAzar = async () => {
    
        const connection = await sql.connect(config);
        const result = await connection.request().query(`SELECT * FROM Preguntas ORDER BY NewId()`);
        return result.recordset[0];
    }

    getPreguntas = async () => {
    
        const connection = await sql.connect(config);
        const result = await connection.request().query(`SELECT * from Preguntas`);
        return result.recordset;
    }
    
    createPregunta = async (pregunta) => {
        const connection = await sql.connect(config);
        const fechaAhora = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
        const result = await connection.request()
            .input('pPregunta', pregunta.pregunta)
            .input('pOpcion1', pregunta.opcion1)
            .input('pOpcion2', pregunta.opcion2)
            .input('pOpcion3', pregunta.opcion3)
            .input('pOpcion4', pregunta.opcion4)
            .input('pRespuestaCorrecta', pregunta.respuestacorrecta)
            .input('pfechaAhora', sql.VarChar, fechaAhora)
            .query('INSERT INTO Preguntas (Pregunta, Opcion1, Opcion2, Opcion3, Opcion4, RespuestaCorrecta, FechaDeCreacion) VALUES (@pPregunta, @pOpcion1, @pOpcion2, @pOpcion3, @pOpcion4, @pRespuestaCorrecta, @pfechaAhora)');

        return result.recordset;
    }

    updatePreguntaById = async (id, pregunta) => {
        const connection = await sql.connect(config);
        const result = await connection.request()
        .input("pId", sql.Int, id)
        .input("pPregunta", pregunta.Pregunta)
        .input("pOpcion1", pregunta.Opcion1)
        .input("pOpcion2", pregunta.Opcion2)
        .input("pOpcion3", pregunta.Opcion3)
        .input("pOpcion4", pregunta.Opcion4)
        .input("pRespuestaCorrecta", pregunta.RespuestaCorrecta)
            .query(`UPDATE Preguntas SET Pregunta = @pPregunta, Opcion1 = @pOpcion1, Opcion2 = @pOpcion2, Opcion3 = @pOpcion3, Opcion4 = @pOpcion4, RespuestaCorrecta = @pRespuestaCorrecta  WHERE IdPregunta = @pId`);

        return result;
    }

    deletePreguntaById = async (id) => {
        const connection = await sql.connect(config);
        const result = await connection.request().input('id',sql.Int, id)
        .query(`DELETE FROM Preguntas where IdPregunta = @id`);
        return result;
    }


}
