import { PreguntaService } from '../services/preguntasService.js';
import { Router } from 'express';
const router = Router();
const Pregunta = new PreguntaService();

router.get('', async (req, res) => {
  const getAll = await Pregunta.getPreguntas();
  res.status(200).send(getAll);
});

router.get('/azar', async (req, res) => {
  const getAll = await Pregunta.getPreguntasByAzar();
  res.status(200).send(getAll);
});

router.post('', async (req, res) => {
  const newPregunta = new PreguntaService();
  newPregunta.pregunta = req.body.Pregunta;
  newPregunta.opcion1 = req.body.Opcion1;
  newPregunta.opcion2 = req.body.Opcion2;
  newPregunta.opcion3 = req.body.Opcion3;
  newPregunta.opcion4 = req.body.Opcion4;
  newPregunta.respuestacorrecta = req.body.RespuestaCorrecta;
  const cPregunta = await Pregunta.createPregunta(newPregunta);
  res.status(201).send(cPregunta);
});

router.put('/:id', async (req, res) => {
  if (req.params.id != req.body.IdPregunta) {
    res.status(400).send();
  }
  const updateResult = await Pregunta.updatePreguntaById(req.params.id, req.body);
  
  console.log(updateResult);
  if (updateResult.rowsAffected[0] == 0) {
    res.status(404).send();
  }
  res.send(updateResult);
});

router.delete('/:id', async (req, res) => {
  const id = req.params.id;
  if (id < 1) {
    res.status(400).send();
  }
  const resultDelete = await Pregunta.deletePreguntaById(id);
  console.log(resultDelete);
  if (resultDelete.rowsAffected[0] == 0) {
    res.status(404).send();
  }
  res.status(200).send();
});

export default router;
