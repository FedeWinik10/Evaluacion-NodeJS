import  { RespuestaService }  from '../services/respuestaService.js';
import { Router } from 'express';
const router = Router()
const Respuesta = new RespuestaService();



router.post('/api/respuesta', async (req, res)=>{
    const respuesta = new Respuesta();
    respuesta.Nombre = req.body.Nombre;
    respuesta.Calorias = req.body.Calorias;
    respuesta.Precio = req.body.Precio;
    respuesta.Descripcion = req.body.Descripcion;
    const cRespuesta = await Respuesta.createRespuesta(respuesta);
    res.status(201).send(cRespuesta);
});

export default router;