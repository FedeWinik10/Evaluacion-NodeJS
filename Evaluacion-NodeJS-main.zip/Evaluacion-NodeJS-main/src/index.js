import express from "express";
import PreguntasRouter from "./controllers/preguntascontroller.js";
import RespuestasRouter from "./controllers/respuestascontroller.js";
const app = express();
const port = 3000;

app.use(express.json());
app.use("/pregunta", PreguntasRouter)
app.use("/respuesta", RespuestasRouter)

app.listen(port, () => {
    console.log(`Se está usando el puerto: ${port}`);
  });


