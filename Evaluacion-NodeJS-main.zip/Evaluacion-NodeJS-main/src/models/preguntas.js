export default class Preguntas{
    idpregunta;
    pregunta;
    opcion1;
    opcion2;
    opcion3;
    opcion4;
    respuestacorrecta;
    fechadecreacion;
}