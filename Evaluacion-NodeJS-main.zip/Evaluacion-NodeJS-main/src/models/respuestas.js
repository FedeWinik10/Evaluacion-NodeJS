class Respuestas{
    idusuario;
    idpregunta;
    respuestaseleccionada;
    respuestacorrecta;
    fechadecreacion;    
}
export default Respuestas;