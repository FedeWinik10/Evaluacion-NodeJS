import 'dotenv/config'
const config = {
    user: 'usuario1',
    password: 'Producto',
    server: 'DESKTOP-91O838P\SQLEXPRESS',
    database: 'PIA 07-2023',
    options:{
        trustServerCertificate: true,
        trustedConnection: true,
    },
}
export default config;